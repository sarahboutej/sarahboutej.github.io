function navToggle() {
  var btn = document.getElementById('hamburger-btn');
  var menu = document.getElementById('hamburger-menu');

  menu.classList.toggle('flex');
  menu.classList.toggle('hidden');
}